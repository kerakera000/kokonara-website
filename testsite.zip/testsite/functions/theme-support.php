<?php

    add_theme_support('post-thumbnails'); //投稿編集のアイキャッチ設定を表示する内容

?>
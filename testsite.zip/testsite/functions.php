<?php

    require_once locate_template('functions/create-post-type.php', true);
    require_once locate_template('functions/custom-taxonomy-cat.php', true);
    require_once locate_template('functions/custom-taxonomy-tag.php', true);
    require_once locate_template('functions/load-scripts.php', true);
    require_once locate_template('functions/theme-support.php', true);
?>
